require('dotenv').config();
const express = require('express');
const cors    = require('cors');
const fetch   = require('node-fetch');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── The key lives only here on the server. It is never sent to the browser. ──
const ZD_KEY    = process.env.ZD_KEY || '38yu0KeUkOGE0u3WKezwX99nW4JgpRBiRo6j1ggf';
const ZD_DOMAIN = 'family1st';
const ZD_BASE   = `https://${ZD_DOMAIN}.zendesk.com/api/v2`;

app.use(cors());
app.use(express.json());

// Serve the HTML tool as the root page
app.use(express.static('public'));

// ── Helper: forward a Zendesk GET, injecting the secret key server-side ──
async function zdGet(path) {
  const res = await fetch(`${ZD_BASE}${path}`, {
    headers: {
      'Authorization': `Bearer ${ZD_KEY}`,
      'Content-Type':  'application/json',
    }
  });
  if (!res.ok) throw new Error(`Zendesk ${res.status}: ${await res.text()}`);
  return res.json();
}

// ── /api/zendesk/updates  →  returns only the IMEI list the frontend needs ──
// The key is used here on the server; the browser never sees it.
app.get('/api/zendesk/updates', async (req, res) => {
  try {
    const twoDaysAgo = new Date(Date.now() - 2 * 24 * 60 * 60 * 1000)
                          .toISOString().slice(0, 10);

    // Search for recently-updated tickets
    let tickets = [];
    try {
      const sd = await zdGet(
        `/search.json?query=type:ticket updated>${twoDaysAgo}&sort_by=updated_at&sort_order=desc&per_page=100`
      );
      tickets = sd.results || [];
    } catch {
      const fd = await zdGet('/tickets/recent.json');
      tickets = (fd.tickets || []).filter(
        t => (t.updated_at || t.created_at) >= twoDaysAgo + 'T00:00:00Z'
      );
    }

    function extractIMEIs(text) {
      if (!text) return [];
      return (String(text).match(/\b\d{14,15}\b/g) || []);
    }

    function imeiFromTicket(ticket) {
      const found = new Set();
      extractIMEIs(ticket.subject).forEach(i => found.add(i));
      extractIMEIs(ticket.description).forEach(i => found.add(i));
      if (Array.isArray(ticket.custom_fields))
        ticket.custom_fields.forEach(f => extractIMEIs(f.value).forEach(i => found.add(i)));
      return found;
    }

    const updatedIMEIs   = new Set();
    const updatedSubjects = [];   // fallback: ticket text for email/username match

    for (const ticket of tickets) {
      try {
        const ticketIMEIs = imeiFromTicket(ticket);
        const cd = await zdGet(`/tickets/${ticket.id}/comments.json`);

        let hasDBUpdate = false;
        const allIMEIs  = new Set([...ticketIMEIs]);
        let   allText   = [ticket.subject, ticket.description, ticket.raw_subject]
                            .filter(Boolean).join(' ');

        for (const comment of (cd.comments || [])) {
          const body = comment.plain_body || comment.body || '';
          allText += ' ' + body;
          if (/DB\s+updated\s+by\s+\S+/i.test(body)) hasDBUpdate = true;
          extractIMEIs(body).forEach(i => allIMEIs.add(i));
        }

        if (hasDBUpdate) {
          const valid = [...allIMEIs].filter(i => i.length >= 14);
          if (valid.length) {
            valid.forEach(i => updatedIMEIs.add(i));
          } else {
            updatedSubjects.push(allText.toLowerCase());
          }
        }
      } catch { /* skip individual ticket errors */ }
    }

    // Return only what the frontend needs — no key, no raw ticket data
    res.json({
      ok:       true,
      imeis:    [...updatedIMEIs],
      subjects: updatedSubjects,
      checked:  tickets.length,
    });

  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.listen(PORT, () =>
  console.log(`DB Tool server running on http://localhost:${PORT}`)
);
