# DB Excel Work Tool

Internal tool for Family1st DB Excel operations.

## How it works

- `server.js` — Node.js backend. Holds the Zendesk API key. Never exposes it to the browser.
- `public/index.html` — The UI. Calls `/api/zendesk/updates` on the local server instead of Zendesk directly.

## Run locally

```bash
npm install
node server.js
# Open http://localhost:3000
```

## Deploy to Render (free, gets a public URL)

1. Push this folder to a GitHub repo (private repo recommended)
2. Go to https://render.com → New → Web Service → connect your repo
3. Build command: `npm install`
4. Start command: `node server.js`
5. Add environment variable in Render dashboard:
   - Key: `ZD_KEY`
   - Value: your Zendesk API key
6. Deploy — Render gives you a public HTTPS URL

The key is stored only in Render's encrypted environment variables.
It is never in the HTML, never in the browser, never in the repo.

## Deploy to Railway

```bash
npm install -g @railway/cli
railway login
railway init
railway up
# Set ZD_KEY in Railway dashboard → Variables
```
